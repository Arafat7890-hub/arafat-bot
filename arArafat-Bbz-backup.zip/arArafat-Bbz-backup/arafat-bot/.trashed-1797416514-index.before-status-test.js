const fs = require("fs");
const { loadCommands } = require("./lib/commandLoader");
const shield = require("./lib/shield/shield");
const linkShield = require("./lib/shield/linkShield");
const mediaShield = require("./lib/shield/mediaShield");
const repeatShield = require("./lib/shield/repeatShield");
const joinShield = require("./lib/shield/joinShield");
const shieldAlert = require("./lib/shield/alert");

let commands = new Map();
const express = require("express");
const pino = require("pino");

const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason
} = require("@whiskeysockets/baileys");

const app = express();
const PORT = 3000;
const AUTH_DIR = "./auth";

app.use(express.json());

let sock = null;
let status = "STARTING";
let pairingCode = null;
let restarting = false;

/* =========================
   WHATSAPP
========================= */

async function startWhatsApp() {
  commands = loadCommands();
  const { state, saveCreds } =
    await useMultiFileAuthState(AUTH_DIR);

  const { version } =
    await fetchLatestBaileysVersion();

  console.log("🌐 WhatsApp Web:", version.join("."));

  sock = makeWASocket({
    auth: state,
    version,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    markOnlineOnConnect: false
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "connecting") {
      status = "CONNECTING";
      console.log("📡 Connecting...");
    }

    if (connection === "open") {
      restarting = false;
      console.log("✅ —͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟ CONNECTED!");
    }

    if (connection === "close") {
      status = "DISCONNECTED";

      const code =
        lastDisconnect?.error?.output?.statusCode;

      console.log("⚠️ Connection closed:", code || "unknown");

      if (
        code !== DisconnectReason.loggedOut &&
        !restarting
      ) {
        restarting = true;

        console.log(
          "🔄 Reconnecting in 3 seconds..."
        );

        setTimeout(() => {
          startWhatsApp().catch((err) => {
            restarting = false;
            status = "ERROR";
            console.log(
              "❌ Restart error:",
              err.message
            );
          });
        }, 3000);
      }
    }
  });

  /* =========================
     MESSAGE HANDLER
  ========================= */

  sock.ev.on("group-participants.update", async (update) => {
  try {
    if (!update?.id || update.action !== "add") return;

    const count = Array.isArray(update.participants)
      ? update.participants.length
      : 0;

    if (!count) return;

    const result = joinShield.check(update.id, count);

    if (result.suspicious) {
      console.log(
        `🛡️ ARAFAT SHIELD | JOIN_BURST | ${update.id} | ${result.count} joins/30s`
      );
    }
  } catch (e) {
    console.log("❌ Shield join error:", e.message);
  }
});

sock.ev.on("messages.upsert", async ({ messages }) => {
  try {
    for (const m of messages || []) {
      const jid = m?.key?.remoteJid || "";
      if (jid === "status@broadcast") {
        console.log(
          "📢 STATUS EVENT:",
          m?.message?.conversation ||
          m?.message?.extendedTextMessage?.text ||
          "[media/status]"
        );
      }
    }
  } catch (e) {
    console.log("⚠️ Status test:", e.message);
  }
});

sock.ev.on("messages.upsert", async ({ messages }) => {
    try {
      const msg = messages[0];

      if (!msg || !msg.message) return;

      const jid = msg.key.remoteJid;

    if (jid && jid.endsWith("@g.us")) {
      const sender = msg.key.participant || jid;
      const result = shield.check(jid, sender);

      if (result.suspicious) {
        console.log(
          `🛡️ ARAFAT SHIELD | ${result.reason} | ${sender} | ${result.count} msgs/10s`
        );

        try {
          const meta =
            global.arafatGroupCache?.get(jid) ||
            await sock.groupMetadata(jid);

          global.arafatGroupCache.set(jid, meta);

          await shieldAlert.sendAlert(
            sock,
            jid,
            sender,
            result.reason,
            result.count,
            meta
          );
        } catch (e) {
          console.log("⚠️ Shield alert:", e.message);
        }
      }
    }

      if (jid && jid.endsWith("@g.us")) {
        global.arafatAnti = global.arafatAnti || { links: new Map(), stickers: new Map() };
        global.arafatGroupCache = global.arafatGroupCache || new Map(); const meta = global.arafatGroupCache.get(jid) || await sock.groupMetadata(jid); global.arafatGroupCache.set(jid, meta);
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderInfo = meta.participants.find(x => x.id === sender);
        const isAdmin = !!senderInfo?.admin;
        const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || "";
        const hasLink = /https?:\/\/|www\.|chat\.whatsapp\.com\//i.test(body);
        const isSticker = !!msg.message?.stickerMessage;

          const linkMode = global.arafatAnti.links.get(jid); if (linkMode && hasLink && (linkMode === "all" || (linkMode === "admin" && isAdmin) || (linkMode === "member" && !isAdmin))) {
          try {
            await sock.sendMessage(jid, { delete: msg.key });
              await sock.sendMessage(jid, { text: "⚠️ 𝗔𝗡𝗧𝗜𝗟𝗜𝗡𝗞 𝗪𝗔𝗥𝗡𝗜𝗡𝗚\n\n🔗 Link detected and deleted. Please do not send links here." });
          } catch (e) {
            console.log("⚠️ Link delete:", e.message);
          }
        }

          const stickerMode = global.arafatAnti.stickers.get(jid); if (stickerMode && isSticker && (stickerMode === "all" || (stickerMode === "admin" && isAdmin) || (stickerMode === "member" && !isAdmin))) {
          try {
            await sock.sendMessage(jid, { delete: msg.key });
              await sock.sendMessage(jid, { text: "⚠️ 𝗔𝗡𝗧𝗜𝗦𝗧𝗜𝗖𝗞𝗘𝗥 𝗪𝗔𝗥𝗡𝗜𝗡𝗚\n\n🎟️ Sticker detected and deleted. Please do not send stickers here." });
          } catch (e) {
            console.log("⚠️ Sticker delete:", e.message);
          }
        }
      }

      if (!jid || jid === "status@broadcast") return;

      const text =
        msg.message.conversation ||
        msg.message.extendedTextMessage?.text ||
        "";

      const command = text.trim().toLowerCase();

    if (command.startsWith(".")) {
      const cmdName = command.slice(1).split(/\s+/)[0];
      const args = command.slice(1).trim().split(/\s+/).slice(1);
      const cmd = commands.get(cmdName);

      // PUBLIC / PRIVATE MODE
      global.arafatMode = global.arafatMode || "public";
      const ownerNumber = "8801890492613";
      const senderJid = msg.key.participant || msg.key.remoteJid || "";
      const senderNumber = senderJid.split("@")[0].split(":")[0];
      const isOwner = msg.key.fromMe || senderNumber === ownerNumber;

      // .mode command: owner only
      if (cmdName === "mode") {
        if (!isOwner) {
          await sock.sendMessage(jid, {
            text: "❌ এই command শুধু Bot Owner ব্যবহার করতে পারবে।"
          });
          return;
        }

        const requestedMode = args[0]?.toLowerCase();

        if (!["public", "private"].includes(requestedMode)) {
          await sock.sendMessage(jid, {
            text: `⚙️ Usage: .mode public / .mode private

Current Mode : ${global.arafatMode.toUpperCase()}`
          });
          return;
        }

        global.arafatMode = requestedMode;

        await sock.sendMessage(jid, {
          text: `╭━━━〔 ⚙️ 𝗕𝗢𝗧 𝗠𝗢𝗗𝗘 〕━━━╮
┃
┃ ✅ Mode : ${requestedMode.toUpperCase()}
┃ 👑 Changed by : Owner
┃
╰━━━━━━━━━━━━━━━━━━━━╯`
        });
        return;
      }

      // PRIVATE mode: only owner can use commands
      if (global.arafatMode === "private" && !isOwner) {
        return;
      }

      if (cmd) {
        try {
          await sock.sendMessage(jid, { react: { text: "⚡", key: msg.key } });
        } catch (e) {}
        await cmd.execute(sock, msg, args);
        return;
      }
    }

      /* .ping */

      if (command === ".ping") {
        await sock.sendMessage(jid, {
          text: "🏓 Pong!\n\n🤖 —͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟ is online."
        });
      }

      /* .menu */

      else if (command === ".menu") {
        await sock.sendMessage(jid, {
          text:
`╔════════════════════╗
      🤖 —͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟
╚════════════════════╝

📌 COMMAND MENU

🏓 .ping
📋 .menu
😈 .shock

━━━━━━━━━━━━━━━━━━━━
⚡ Bot Status: ONLINE
━━━━━━━━━━━━━━━━━━━━`
        });
      }

      /* .shock */

      else if (command === ".shock") {
        await sock.sendMessage(jid, {
          text:
`⚡ SYSTEM SCAN STARTED...

🔍 Checking system...
🔍 Checking network...
🔍 Checking files...

████████████████ 100%

😈 PRANK COMPLETE 😂

কোনো আসল scan হয়নি।
এটা শুধু —͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟-এর fake prank. 🤖`
        });
      }

    } catch (error) {
      console.log(
        "❌ Message error:",
        error.message
      );
    }
  });
}

/* =========================
   WEB PANEL
========================= */

app.get("/", (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport"
content="width=device-width,initial-scale=1">

<title>—͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟</title>

<style>
*{box-sizing:border-box}

body{
  margin:0;
  min-height:100vh;
  background:radial-gradient(
    circle at top,
    #172554,
    #020617 65%
  );
  color:white;
  font-family:Arial,sans-serif;
  display:flex;
  align-items:center;
  justify-content:center;
}

.panel{
  width:92%;
  max-width:460px;
  padding:30px;
  border-radius:25px;
  background:rgba(15,23,42,.94);
  border:1px solid rgba(255,255,255,.12);
  box-shadow:0 25px 80px rgba(0,0,0,.6);
}

.logo{
  text-align:center;
  font-size:31px;
  font-weight:800;
}

.sub{
  text-align:center;
  color:#94a3b8;
  margin-top:7px;
  margin-bottom:30px;
}

.statusBox{
  margin-top:22px;
  padding:17px;
  border-radius:15px;
  background:#020617;
  border:1px solid #1e293b;
}

.statusTitle{
  color:#94a3b8;
}

#status{
  font-weight:bold;
  margin-top:6px;
}

.code{
  margin-top:18px;
  text-align:center;
  font-size:30px;
  font-weight:800;
  letter-spacing:6px;
  color:#60a5fa;
}

.help{
  margin-top:15px;
  text-align:center;
  color:#64748b;
  font-size:12px;
}
</style>
</head>

<body>

<div class="panel">

<div class="logo">
🤖 —͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟
</div>

<div class="sub">
WhatsApp Bot Control Panel
</div>

<div class="statusBox">

<div class="statusTitle">
Connection Status
</div>

<div id="status">
Checking...
</div>

<div id="code" class="code"></div>

</div>

<div class="help">
—͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟ • WhatsApp
</div>

</div>

<script>

async function updateStatus(){

try{

const response =
await fetch("/status");

const data =
await response.json();

document.getElementById("status")
.innerText = data.status;

}catch(e){

document.getElementById("status")
.innerText =
"SERVER OFFLINE";

}

}

setInterval(updateStatus,2000);
updateStatus();

</script>

</body>
</html>
  `);
});

/* =========================
   STATUS API
========================= */

app.get("/status", (req, res) => {
  res.json({
    status,
    code: pairingCode
  });
});

/* =========================
   SERVER
========================= */

app.listen(PORT, () => {

  console.log(`
╔══════════════════════════════╗
║        🤖 —͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟        ║
║       WEB PANEL ONLINE      ║
╚══════════════════════════════╝

🌐 http://127.0.0.1:${PORT}

`);

  startWhatsApp().catch((error) => {

    status = "ERROR";

    console.log(
      "❌ WhatsApp startup error:",
      error.message
    );

  });

});
