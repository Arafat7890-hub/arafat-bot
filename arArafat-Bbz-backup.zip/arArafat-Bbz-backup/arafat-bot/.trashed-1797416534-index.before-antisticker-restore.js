const fs = require("fs");
const { loadCommands } = require("./lib/commandLoader");
const shield = require("./lib/shield/shield");
const linkShield = require("./lib/shield/linkShield");
const mediaShield = require("./lib/shield/mediaShield");
const repeatShield = require("./lib/shield/repeatShield");
const joinShield = require("./lib/shield/joinShield");
const shieldAlert = require("./lib/shield/alert");

let commands = new Map();
const express = require("express");
const smartReply = require("./lib/smartReply");
const protection = require("./lib/protection");
const antiBot = require("./lib/antiBot");
const pino = require("pino");

const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason
} = require("@whiskeysockets/baileys");

const app = express();
const PORT = 3000;
const AUTH_DIR = "./auth";

app.use(express.json());
app.use(express.static("public"));

let sock = null;
let status = "STARTING";
let pairingCode = null;
let restarting = false;

/* =========================
   WHATSAPP
========================= */

async function startWhatsApp() {
  commands = loadCommands();

  const { startSession } =
    require("./lib/sessionConnector");

  console.log("🔌 Starting MAIN BOT from SESSION 1...");

  sock = await startSession("1");


  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "connecting") {
      status = "CONNECTING";
      console.log("📡 Connecting...");
    }

    if (connection === "open") {
      const wasReconnect =
        status === "DISCONNECTED" || status === "ERROR";

      restarting = false;
      status = "CONNECTED";

      console.log("✅ —͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟ CONNECTED!");

      const connectionNotice = wasReconnect
        ? `╭━━━━━━━━━━━━━━━━━━━━━━╮
┃   🔄 𝗖𝗢𝗡𝗡𝗘𝗖𝗧𝗜𝗢𝗡 𝗥𝗘𝗦𝗧𝗢𝗥𝗘𝗗
┣━━━━━━━━━━━━━━━━━━━━━━┫
┃
┃  🟢 𝗔𝗿𝗮𝗳𝗮𝘁 𝗕𝗯𝘇 𝗶𝘀 𝗕𝗮𝗰𝗸!
┃  📡 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗢𝗡𝗟𝗜𝗡𝗘
┃  ⚡ 𝗦𝘆𝘀𝘁𝗲𝗺 : 𝗥𝗘𝗔𝗗𝗬
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`
        : `╭━━━━━━━━━━━━━━━━━━━━━━╮
┃   ✦ 𝗔𝗥𝗔𝗙𝗔𝗧 𝗕𝗕𝗭 𝗖𝗢𝗡𝗡𝗘𝗖𝗧 ✦
┣━━━━━━━━━━━━━━━━━━━━━━┫
┃
┃  🟢 𝗖𝗢𝗡𝗡𝗘𝗖𝗧𝗘𝗗 𝗦𝗨𝗖𝗖𝗘𝗦𝗦𝗙𝗨𝗟𝗟𝗬
┃  🤖 𝗕𝗼𝘁 : 𝗔𝗿𝗮𝗳𝗮𝘁 𝗕𝗯𝘇
┃  📡 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗢𝗡𝗟𝗜𝗡𝗘
┃  ⚡ 𝗦𝘆𝘀𝘁𝗲𝗺 : 𝗥𝗘𝗔𝗗𝗬
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`;

      const myJid = "8801890492613@s.whatsapp.net";

      if (myJid) {
        sock.sendMessage(myJid, {
          text: connectionNotice
        }).then(() => {
          console.log("📩 Connection notification sent.");
        }).catch((e) => {
          console.log("⚠️ Connection notification failed:", e.message);
        });
      }
    }

    if (connection === "close") {
      status = "DISCONNECTED";

      const code =
        lastDisconnect?.error?.output?.statusCode;

      console.log("⚠️ Connection closed:", code || "unknown");

      if (
        code !== DisconnectReason.loggedOut &&
        !restarting
      ) {
        restarting = true;

        console.log(
          "🔄 Reconnecting in 3 seconds..."
        );

        setTimeout(() => {
          startWhatsApp().catch((err) => {
            restarting = false;
            status = "ERROR";
            console.log(
              "❌ Restart error:",
              err.message
            );
          });
        }, 3000);
      }
    }
  });

  /* =========================
     MESSAGE HANDLER
  ========================= */

  sock.ev.on("group-participants.update", async (update) => {
  try {
    if (!update?.id || update.action !== "add") return;

    const count = Array.isArray(update.participants)
      ? update.participants.length
      : 0;

    if (!count) return;

    // AntiBot: only removes accounts explicitly marked as bots.
    const botProtection = protection.get(update.id);

    if (
      botProtection.antibot &&
      Array.isArray(update.participants)
    ) {
      for (const participant of update.participants) {
        const target =
          participant?.id ||
          participant?.phoneNumber ||
          participant?.lid;

        if (!target) continue;

        if (protection.isKnownBot(update.id, target)) {
          try {
            await sock.sendMessage(update.id, {
              text:
                "⚠️ 𝗔𝗡𝗧𝗜𝗕𝗢𝗧 𝗗𝗘𝗧𝗘𝗖𝗧𝗘𝗗\n\n" +
                `🤖 Marked bot detected: ${target}\n` +
                "🚫 Member will be removed by protection."
            });

            await sock.groupParticipantsUpdate(
              update.id,
              [target],
              "remove"
            );

            console.log(
              `🤖 ARAFAT ANTIBOT | REMOVED | ${target} | ${update.id}`
            );
          } catch (e) {
            console.log(
              "⚠️ AntiBot remove error:",
              e.message
            );
          }
        }
      }
    }

    const result = joinShield.check(update.id, count);

    if (result.suspicious) {
      console.log(
        `🛡️ ARAFAT SHIELD | JOIN_BURST | ${update.id} | ${result.count} joins/30s`
      );
    }
  } catch (e) {
    console.log("❌ Shield join error:", e.message);
  }
});



sock.ev.on("messages.upsert", async ({ messages, type }) => {
  console.log("📩 MESSAGE EVENT RECEIVED:", messages?.length || 0, "TYPE:", type);

  for (const dbg of messages || []) {
    const dk = dbg?.key || {};
    const dm = dbg?.message || {};

    if (
      dk.remoteJid === "status@broadcast" ||
      Object.keys(dm).some(k => k.toLowerCase().includes("status"))
    ) {
      console.log("🔥🔥 STATUS EVENT DEBUG 🔥🔥");
      console.log("STATUS KEY:", JSON.stringify(dk, null, 2));
      console.log("STATUS MESSAGE KEYS:", Object.keys(dm));
      console.log("STATUS MESSAGE:", JSON.stringify(dm, null, 2));
    }
  }
    try {
    // Message debug logs disabled

for (const x of messages || []) {
  const m = x?.message || {};
  const key = x?.key || {};

  // ═══════════════════════════════════════
  // 🛡️ ARAFAT GC STATUS AUTO PROTECTION
  // ═══════════════════════════════════════
  if (m.groupStatusMessage || m.groupStatusMessageV2) {

    const groupJid = key.remoteJid || "";

    if (!groupJid.endsWith("@g.us")) {
      continue;
    }

    const senderLid = key.participant || "";
    const senderPn = key.participantAlt || "";

    const senderCandidates = [
      senderLid,
      senderPn
    ].filter(Boolean);

    const statusId = key.id || "";

    if (!statusId || senderCandidates.length === 0) {
      console.log("⚠️ GC STATUS: incomplete message key");
      continue;
    }

    // Prevent duplicate processing
    global.gcStatusSeen = global.gcStatusSeen || new Map();

    const seenKey =
      `${groupJid}:${statusId}:${senderLid}:${senderPn}`;

    if (global.gcStatusSeen.has(seenKey)) {
      console.log("♻️ GC STATUS: duplicate ignored");
      continue;
    }

    global.gcStatusSeen.set(seenKey, Date.now());

    // Keep memory clean
    setTimeout(() => {
      global.gcStatusSeen?.delete(seenKey);
    }, 10 * 60 * 1000);

    console.log("🔥 GC STATUS DETECTED");
    console.log("📌 GROUP:", groupJid);
    console.log("👤 LID:", senderLid);
    console.log("📱 PN:", senderPn);
    console.log("🆔 ID:", statusId);

    try {
      // Get fresh group metadata
      const meta = await sock.groupMetadata(groupJid);

      const participant = (meta.participants || []).find(p => {
        const ids = [
          p.id,
          p.jid,
          p.phoneNumber,
          p.lid
        ].filter(Boolean);

        return senderCandidates.some(sender =>
          ids.includes(sender)
        );
      });

      if (!participant) {
        console.log("⚠️ GC STATUS: sender not found in group");
        continue;
      }

      const isAdmin =
        participant.admin === "admin" ||
        participant.admin === "superadmin" ||
        participant.isAdmin === true ||
        participant.isSuperAdmin === true;

      // 👑 ADMIN BYPASS
      if (isAdmin) {
        console.log(
          `👑 GC STATUS: ADMIN BYPASS | ${senderLid || senderPn}`
        );
        continue;
      }

      console.log(
        `🚨 GC STATUS: MEMBER DETECTED | ${senderLid || senderPn}`
      );

      // Detection message
      await sock.sendMessage(groupJid, {
        text: `╭━━━━━━━━━━━━━━━━━━━━━━╮
┃   🚨 𝗚𝗖 𝗦𝗧𝗔𝗧𝗨𝗦 𝗗𝗘𝗧𝗘𝗖𝗧𝗘𝗗
┣━━━━━━━━━━━━━━━━━━━━━━┫
┃
┃ 👤 Member status detected
┃ 🔍 Protection activated
┃ ⏳ Removing status...
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`
      });

      // 1 second protection delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      /*
       * IMPORTANT:
       * Preserve BOTH LID and PN.
       * WhatsApp may identify the group participant
       * through either addressing form.
       */
      const deleteKey = {
        remoteJid: groupJid,
        fromMe: false,
        id: statusId,
        participant: senderLid || senderPn,
        ...(senderPn ? { participantAlt: senderPn } : {})
      };

      console.log(
        "🗑️ GC STATUS: DELETE REQUEST",
        JSON.stringify(deleteKey)
      );

      try {
        await sock.sendMessage(groupJid, {
          delete: deleteKey
        });

        console.log(
          `🗑️ GC STATUS: DELETE REQUEST ACCEPTED | ${statusId}`
        );

        /*
         * Baileys resolves the relay request; it does not provide
         * a synchronous "WhatsApp UI disappeared" confirmation.
         * Therefore we call this REQUEST ACCEPTED, not fake SUCCESS.
         */
        await sock.sendMessage(groupJid, {
          text: `╭━━━━━━━━━━━━━━━━━━━━━━╮
┃   🗑️ 𝗦𝗧𝗔𝗧𝗨𝗦 𝗥𝗘𝗠𝗢𝗩𝗘 𝗥𝗘𝗤𝗨𝗘𝗦𝗧𝗘𝗗
┣━━━━━━━━━━━━━━━━━━━━━━┫
┃
┃ 👤 Member status detected
┃ 🗑️ Removal request sent
┃ ⚠️ Group status protection
┃
┃ 🚫 Please do not post
┃    unauthorized group status.
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`
        });

        console.log(
          `⚠️ GC STATUS: WARNING SENT | ${statusId}`
        );

      } catch (deleteError) {

        console.log(
          "❌ GC STATUS DELETE FAILED:",
          deleteError?.stack ||
          deleteError?.message ||
          deleteError
        );

        await sock.sendMessage(groupJid, {
          text: `╭━━━━━━━━━━━━━━━━━━━━━━╮
┃   ❌ 𝗦𝗧𝗔𝗧𝗨𝗦 𝗥𝗘𝗠𝗢𝗩𝗔𝗟 𝗙𝗔𝗜𝗟𝗘𝗗
┣━━━━━━━━━━━━━━━━━━━━━━┫
┃
┃ ⚠️ Delete request failed
┃ 🔐 Check bot admin status
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`
        });
      }

    } catch (statusError) {

      console.log(
        "❌ GC STATUS HANDLER ERROR:",
        statusError?.stack ||
        statusError?.message ||
        statusError
      );
    }
  }
}

      if (type !== "notify") return;

    if (!Array.isArray(messages) || messages.length === 0) return;
    console.log("🟢 LIVE EVENT:", type, messages.length);

      for (const msg of messages) {
        if (!msg) continue;

        // Ignore WhatsApp newsletter/channel events
        const msgJid = msg.key?.remoteJid || "";
        if (msgJid.endsWith("@newsletter")) continue;

        console.log("🟡 PROCESSING MESSAGE:", msg.key?.remoteJid, msg.key?.id);
        console.log("🧩 MESSAGE KEYS:", Object.keys(msg.message || {}));
        console.log("🧩 STUB:", msg.messageStubType || "none", msg.messageStubParameters || []);

      try {
        await smartReply.handle(sock, msg);
      } catch (e) {
        console.log("⚠️ Smart Reply:", e.message);
      }

      console.log("🟢 SMART REPLY DONE:", msg.key?.id);

      const debugText =
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        "";

      console.log("🔎 MESSAGE TEXT:", JSON.stringify(debugText));

      const jid = msg.key.remoteJid;

      // ⚡ FAST GROUP METADATA CACHE
      let groupMeta = null;
      if (jid && jid.endsWith("@g.us")) {
        try {
          global.arafatGroupCache = global.arafatGroupCache || new Map();
          groupMeta =
            global.arafatGroupCache.get(jid) ||
            await sock.groupMetadata(jid);
          global.arafatGroupCache.set(jid, groupMeta);
        } catch (e) {
          console.log("⚠️ Group metadata:", e.message);
        }
      }


      // COMMAND PARSER
      const text =
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        msg.message?.imageMessage?.caption ||
        msg.message?.videoMessage?.caption ||
        "";

      const command = text.trim().toLowerCase();
      console.log("🔎 PARSER TEXT:", JSON.stringify(text));

      let cmdName = "";
      let args = [];
      let cmd = null;

      if (command.startsWith(".")) {
        cmdName = command.slice(1).split(/\s+/)[0];
        args = command.slice(1).trim().split(/\s+/).slice(1);
        cmd = commands.get(cmdName);
      }

      // PUBLIC / PRIVATE MODE
      global.arafatMode = global.arafatMode || "public";
      const ownerNumber = "8801890492613";
      const senderJid = msg.key.participant || msg.key.remoteJid || "";
      const senderNumber = senderJid.split("@")[0].split(":")[0];
      const isOwner = msg.key.fromMe || senderNumber === ownerNumber;

      // .mode command: owner only
      if (cmdName === "mode") {
        if (!isOwner) {
          await sock.sendMessage(jid, {
            text: "❌ এই command শুধু Bot Owner ব্যবহার করতে পারবে।"
          });
          return;
        }

        const requestedMode = args[0]?.toLowerCase();

        if (!["public", "private"].includes(requestedMode)) {
          await sock.sendMessage(jid, {
            text: `⚙️ Usage: .mode public / .mode private

Current Mode : ${global.arafatMode.toUpperCase()}`
          });
          return;
        }

        global.arafatMode = requestedMode;

        await sock.sendMessage(jid, {
          text: `╭━━━〔 ⚙️ 𝗕𝗢𝗧 𝗠𝗢𝗗𝗘 〕━━━╮
┃
┃ ✅ Mode : ${requestedMode.toUpperCase()}
┃ 👑 Changed by : Owner
┃
╰━━━━━━━━━━━━━━━━━━━━╯`
        });
        return;
      }

      // PRIVATE mode: only owner can use commands
      if (global.arafatMode === "private" && !isOwner) {
        return;
      }

      if (cmd) {
        try {
          await sock.sendMessage(jid, { react: { text: "⚡", key: msg.key } });
        } catch (e) {}
        await cmd.execute(sock, msg, args);
        return;
      }
    }



    } catch (error) {
      console.log(
        "❌ Message error:",
        error.message
      );
    }
  });
}

/* =========================
   WEB PANEL
========================= */

app.get("/", (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport"
content="width=device-width,initial-scale=1">

<title>—͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟</title>

<style>
*{box-sizing:border-box}

body{
  margin:0;
  min-height:100vh;
  background:radial-gradient(
    circle at top,
    #172554,
    #020617 65%
  );
  color:white;
  font-family:Arial,sans-serif;
  display:flex;
  align-items:center;
  justify-content:center;
}

.panel{
  width:92%;
  max-width:460px;
  padding:30px;
  border-radius:25px;
  background:rgba(15,23,42,.94);
  border:1px solid rgba(255,255,255,.12);
  box-shadow:0 25px 80px rgba(0,0,0,.6);
}

.logo{
  text-align:center;
  font-size:31px;
  font-weight:800;
}

.sub{
  text-align:center;
  color:#94a3b8;
  margin-top:7px;
  margin-bottom:30px;
}

.statusBox{
  margin-top:22px;
  padding:17px;
  border-radius:15px;
  background:#020617;
  border:1px solid #1e293b;
}

.statusTitle{
  color:#94a3b8;
}

#status{
  font-weight:bold;
  margin-top:6px;
}

.code{
  margin-top:18px;
  text-align:center;
  font-size:30px;
  font-weight:800;
  letter-spacing:6px;
  color:#60a5fa;
}

.help{
  margin-top:15px;
  text-align:center;
  color:#64748b;
  font-size:12px;
}
</style>
</head>

<body>

<div class="panel">

<div class="logo">
🤖 —͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟
</div>

<div class="sub">
WhatsApp Bot Control Panel
</div>

<div class="statusBox">

<div class="statusTitle">
Connection Status
</div>

<div id="status">
Checking...
</div>

<div id="code" class="code"></div>

</div>

<div class="help">
—͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟ • WhatsApp
</div>

</div>

<script>

async function updateStatus(){

try{

const response =
await fetch("/status");

const data =
await response.json();

document.getElementById("status")
.innerText = data.status;

}catch(e){

document.getElementById("status")
.innerText =
"SERVER OFFLINE";

}

}

setInterval(updateStatus,2000);
updateStatus();

</script>

</body>
</html>
  `);
});

/* =========================
   STATUS API
========================= */


app.post("/api/pair", async (req, res) => {
  try {
    const { slot = "1", phone } = req.body || {};

    const number = String(phone || "").replace(/\D/g, "");

    if (!number) {
      return res.status(400).json({
        ok: false,
        error: "Phone number required"
      });
    }

    const {
      startSession,
      requestPairingCode
    } = require("./lib/sessionConnector");

    await startSession(String(slot));

    const code = await requestPairingCode(
      String(slot),
      number
    );

    res.json({
      ok: true,
      slot: String(slot),
      code
    });

  } catch (error) {
    console.log("❌ PAIR API:", error.message);

    res.status(500).json({
      ok: false,
      error: error.message
    });
  }
});

app.get("/status", (req, res) => {
  let sessionStats = {
    max: 50,
    used: 0,
    active: 0,
    connecting: 0,
    empty: 50
  };

  try {
    const sessionManager = require("./lib/sessionManager");
    sessionStats = sessionManager.stats();
  } catch (e) {
    console.log("⚠️ Session stats:", e.message);
  }

  res.json({
    status,
    code: pairingCode,
    sessions: sessionStats
  });
});

/* =========================
   SERVER
========================= */

app.listen(PORT, () => {

  console.log(`
╔══════════════════════════════╗
║        🤖 —͟͞͞𝗔ʀᴀꜰᴀᴛㅤBbz ᥫ᭡፝֟        ║
║       WEB PANEL ONLINE      ║
╚══════════════════════════════╝

🌐 http://127.0.0.1:${PORT}

`);

  startWhatsApp().catch((error) => {

    status = "ERROR";

    console.log(
      "❌ WhatsApp startup error:",
      error.message
    );

  });

});
