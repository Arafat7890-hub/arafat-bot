module.exports = {
  name: "desc",
  aliases: ["description"],
  category: "Group",
  description: "Show group description",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    if (!jid?.endsWith("@g.us"))
      return sock.sendMessage(jid, {
        text: "❌ শুধু Group-এ ব্যবহার করা যাবে।"
      });

    const meta = await sock.groupMetadata(jid);
    const desc = meta.desc || "কোনো description সেট করা নেই।";

    await sock.sendMessage(jid, {
      text: `╭━━━〔 📝 𝗚𝗥𝗢𝗨𝗣 𝗗𝗘𝗦𝗖 〕━━━╮
┃
┃ 🏷️ ${meta.subject}
┃
┃ ${desc}
┃
╰━━━━━━━━━━━━━━━━━━━━╯`
    });
  }
};
