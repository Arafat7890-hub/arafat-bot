module.exports={
  name:"description",
  aliases:["gcdescription"],
  category:"Group",
  description:"Change group description",
  async execute(sock,msg,args){
    const jid=msg.key.remoteJid;
    const text=args.join(" ").trim();
    if(!jid?.endsWith("@g.us"))return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    if(!text)return sock.sendMessage(jid,{text:"❌ Description দাও।"});
    try{
      await sock.groupUpdateDescription(jid,text);
      await sock.sendMessage(jid,{text:"✅ Group description updated."});
    }catch(e){await sock.sendMessage(jid,{text:"❌ Failed: "+e.message});}
  }
};
