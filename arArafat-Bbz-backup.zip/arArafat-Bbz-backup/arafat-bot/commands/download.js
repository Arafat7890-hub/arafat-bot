const fs=require("fs");
const path=require("path");
const {downloadMediaMessage}=require("@whiskeysockets/baileys");

module.exports={
  name:"download",
  aliases:["dlmedia","savefile"],
  category:"Media",
  description:"Download replied media",
  async execute(sock,msg){
    const jid=msg.key.remoteJid;
    const q=msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    if(!q)return sock.sendMessage(jid,{text:"❌ আগে image/video/audio/document-এ reply করো।"});
    try{
      const quoted={key:{remoteJid:jid,id:msg.message.extendedTextMessage.contextInfo.stanzaId,participant:msg.message.extendedTextMessage.contextInfo.participant},message:q};
      const buffer=await downloadMediaMessage(quoted,"buffer",{},{});
      const dir=path.join(__dirname,"..","downloads");
      fs.mkdirSync(dir,{recursive:true});
      const file=path.join(dir,`media-${Date.now()}.bin`);
      fs.writeFileSync(file,buffer);
      await sock.sendMessage(jid,{text:`✅ Media saved:\n${file}`});
    }catch(e){await sock.sendMessage(jid,{text:"❌ Download failed: "+e.message});}
  }
};
