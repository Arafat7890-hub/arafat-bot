module.exports = {
  name: "echo",
  aliases: ["repeat"],
  category: "Tools",
  description: "Repeat text with style",

  async execute(sock, msg, args) {
    const text = args.join(" ");

    if (!text)
      return sock.sendMessage(msg.key.remoteJid, {
        text: "⚙️ Usage: .echo Hello"
      });

    await sock.sendMessage(msg.key.remoteJid, {
      text: `╭━━━〔 🔊 ᴇᴄʜᴏ 〕━━━╮\n┃\n┃ ${text}\n┃\n╰━━━━━━━━━━━━━━━━╯`
    });
  }
};
