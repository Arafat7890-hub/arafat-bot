module.exports={
  name:"edit",
  aliases:["ed"],
  category:"Message",
  description:"Edit your replied message",
  async execute(sock,msg,args){
    const jid=msg.key.remoteJid;
    const id=msg.message?.extendedTextMessage?.contextInfo?.stanzaId;
    if(!id) return sock.sendMessage(jid,{text:"❌ নিজের message-এ reply করে `.edit নতুন লেখা` দাও।"});
    const text=args.join(" ").trim();
    if(!text) return sock.sendMessage(jid,{text:"❌ নতুন text দাও।"});
    try{
      await sock.sendMessage(jid,{text,edit:{
        remoteJid:jid,
        id,
        fromMe:true
      }});
    }catch(e){
      await sock.sendMessage(jid,{text:"❌ Edit failed: "+e.message});
    }
  }
};
