module.exports = {
  name: "8ball",
  aliases: ["eightball"],
  category: "Fun",
  description: "Answer a yes/no question",
  async execute(sock, msg, args) {
    const answers = ["✨ ʏᴇs", "🌙 ᴍᴀʏʙᴇ", "💫 ᴅᴇғɪɴɪᴛᴇʟʏ", "🤔 ᴜɴᴄᴇʀᴛᴀɪɴ", "❌ ɴᴏ"];
    if (!args.length) return sock.sendMessage(msg.key.remoteJid, { text: "🎱 ব্যবহার: .8ball তোমার প্রশ্ন" });
    const answer = answers[Math.floor(Math.random() * answers.length)];
    await sock.sendMessage(msg.key.remoteJid, { text: `╭━━〔 🎱 𝟾ʙᴀʟʟ 〕━━╮\n┃\n┃ ❓ ${args.join(" ")}\n┃ 🔮 ${answer}\n┃\n╰━━━━━━━━━━━━╯` });
  }
};
