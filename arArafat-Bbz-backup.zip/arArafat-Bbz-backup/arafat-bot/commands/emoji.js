module.exports={name:"emoji",aliases:["emojify"],category:"Fun",description:"Repeat emoji",async execute(sock,msg,args){
const jid=msg.key.remoteJid,e=args[0]||"✨",n=Math.min(Math.max(parseInt(args[1]||"10"),1),50);
await sock.sendMessage(jid,{text:e.repeat(n)});
}};
