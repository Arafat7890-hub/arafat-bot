const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");
const { promisify } = require("util");

const execFileAsync = promisify(execFile);

const ROOT = path.join(__dirname, "..");
const BIN = path.join(ROOT, "realsr/extracted/assets/realsr/realsr-ncnn");
const MODEL = path.join(ROOT, "realsr/extracted/assets/realsr/models-Real-ESRGAN");

module.exports = {
  name: "enhance",
  aliases: ["enhancehd", "clarity", "hq"],
  category: "Media",
  description: "AI photo enhancement",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

    if (!quoted?.imageMessage) {
      return sock.sendMessage(jid, {
        text: "🖼️ একটি ছবিতে reply করে ব্যবহার করো:\n\n✨ .enhance"
      });
    }

    const id = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const input = path.join(ROOT, `enh_in_${id}.jpg`);
    const small = path.join(ROOT, `enh_small_${id}.jpg`);
    const output = path.join(ROOT, `enh_out_${id}.jpg`);

    try {
      const stream = await downloadContentFromMessage(
        quoted.imageMessage,
        "image"
      );

      const chunks = [];
      for await (const chunk of stream) chunks.push(chunk);

      fs.writeFileSync(input, Buffer.concat(chunks));

      // Keep AI input small for much faster processing on Android.
      await execFileAsync("magick", [
        input,
        "-auto-orient",
        "-resize", "600x600>",
        "-quality", "92",
        small
      ]);

      await execFileAsync(
        BIN,
        [
          "-i", small,
          "-o", output,
          "-m", MODEL,
          "-s", "2",
          "-g", "-1",
          "-j", "2:2:2"
        ],
        {
          env: {
            ...process.env,
            LD_LIBRARY_PATH: path.dirname(BIN)
          }
        }
      );


      await sock.sendMessage(jid, {
        image: { url: output },
        mimetype: "image/jpeg",
        caption:
          "✨ ᴀɪ ᴇɴʜᴀɴᴄᴇᴅ\n\n" +
          "🔍 ᴅᴇᴛᴀɪʟ ʙᴏᴏsᴛ\n" +
          "💎 ʀᴇᴀʟ-ᴇsʀɢᴀɴ\n" +
          "⚡ ғᴀsᴛ ᴍᴏᴅᴇ"
      });

    } catch (e) {
      console.log("❌ AI Enhance:", e.stderr || e.message);

      await sock.sendMessage(jid, {
        text: "❌ AI enhance করা যায়নি।"
      });

    } finally {
      for (const file of [input, small, output]) {
        try { fs.unlinkSync(file); } catch {}
      }
    }
  }
};
