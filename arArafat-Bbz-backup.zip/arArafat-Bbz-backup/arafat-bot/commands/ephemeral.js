module.exports = {
  name: "ephemeral",
  aliases: ["disappearing"],
  category: "Admin",
  description: "Set disappearing messages",

  async execute(sock, msg, args) {
    const jid = msg.key.remoteJid;

    if (!jid?.endsWith("@g.us"))
      return sock.sendMessage(jid, {
        text: "❌ এই command শুধু Group-এ ব্যবহার করা যাবে।"
      });

    const meta = await sock.groupMetadata(jid);
    const sender = msg.key.participant || msg.key.remoteJid;
    const me = meta.participants.find(p => p.id === sender);

    if (!me?.admin)
      return sock.sendMessage(jid, {
        text: "❌ শুধু Group Admin ব্যবহার করতে পারবে।"
      });

    const mode = (args[0] || "").toLowerCase();

    const durations = {
      "24h": 86400,
      "7d": 604800,
      "90d": 7776000,
      "off": 0
    };

    if (!(mode in durations))
      return sock.sendMessage(jid, {
        text: "⚙️ Usage:\n.ephemeral 24h\n.ephemeral 7d\n.ephemeral 90d\n.ephemeral off"
      });

    try {
      await sock.groupToggleEphemeral(jid, durations[mode]);

      await sock.sendMessage(jid, {
        text: mode === "off"
          ? "🔓 𝗘𝗣𝗛𝗘𝗠𝗘𝗥𝗔𝗟\n\n✅ Disappearing messages OFF."
          : `⏳ 𝗘𝗣𝗛𝗘𝗠𝗘𝗥𝗔𝗟\n\n✅ Messages will disappear after ${mode}.`
      });
    } catch {
      await sock.sendMessage(jid, {
        text: "❌ Ephemeral setting update failed."
      });
    }
  }
};
