module.exports={
  name:"ephemeralset",
  aliases:["disappearing"],
  category:"Group",
  description:"Set disappearing messages",
  async execute(sock,msg,args){
    const jid=msg.key.remoteJid;
    if(!jid?.endsWith("@g.us")) return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    const map={off:0,"24h":86400,"7d":604800,"90d":7776000};
    const v=map[(args[0]||"").toLowerCase()];
    if(v===undefined)return sock.sendMessage(jid,{text:"❌ Use: `.ephemeralset off|24h|7d|90d`"});
    try{
      await sock.groupToggleEphemeral(jid,v);
      await sock.sendMessage(jid,{text:`✅ Disappearing messages: ${v?args[0]:"OFF"}`});
    }catch(e){await sock.sendMessage(jid,{text:"❌ Failed: "+e.message});}
  }
};
