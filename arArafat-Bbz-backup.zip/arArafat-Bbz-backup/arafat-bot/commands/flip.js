module.exports = {
  name: "flip",
  aliases: ["coin"],
  category: "Fun",
  description: "Flip a coin",

  async execute(sock, msg) {
    const result = Math.random() < 0.5 ? "🪙 ʜᴇᴀᴅs" : "🪙 ᴛᴀɪʟs";

    await sock.sendMessage(msg.key.remoteJid, {
      text: `╭━━━〔 🪙 ғʟɪᴘ 〕━━━╮\n┃\n┃ ➤ ${result}\n┃\n╰━━━━━━━━━━━━━━━━╯`
    });
  }
};
