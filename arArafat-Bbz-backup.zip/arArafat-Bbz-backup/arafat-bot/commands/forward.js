module.exports={
  name:"forward",
  aliases:["fwd"],
  category:"Message",
  description:"Forward a replied message",
  async execute(sock,msg){
    const jid=msg.key.remoteJid;
    const quoted=msg.message?.extendedTextMessage?.contextInfo;
    if(!quoted?.quotedMessage) return sock.sendMessage(jid,{text:"❌ আগে কোনো message-এ reply করো।"});
    try{
      const message={
        key:{
          remoteJid:jid,
          id:quoted.stanzaId,
          participant:quoted.participant
        },
        message:quoted.quotedMessage
      };
      await sock.sendMessage(jid,{forward:message});
    }catch(e){
      await sock.sendMessage(jid,{text:"❌ Forward failed: "+e.message});
    }
  }
};
