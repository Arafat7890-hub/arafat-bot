const fs = require("fs");
const path = require("path");

module.exports = {
  name: "fullpp",
  aliases: ["setpp"],
  category: "Owner",
  description: "Set bot profile picture from profile.jpg",

  async execute(sock, msg) {
    const file = path.join(__dirname, "..", "profile.jpg");

    if (!fs.existsSync(file)) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: "❌ profile.jpg পাওয়া যায়নি।"
      });
    }

    try {
      await sock.updateProfilePicture(sock.user.id, {
        url: file
      });

      await sock.sendMessage(msg.key.remoteJid, {
        text: "✅ 𝗙𝗨𝗟𝗟 𝗣𝗣\n\nBot profile picture updated successfully."
      });
    } catch (e) {
      await sock.sendMessage(msg.key.remoteJid, {
        text: "❌ Profile picture update failed."
      });
    }
  }
};
