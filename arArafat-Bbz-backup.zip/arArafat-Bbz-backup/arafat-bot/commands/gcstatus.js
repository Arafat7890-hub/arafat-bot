const statusStore = require("../lib/groupStatusStore");

const {
  jidNormalizedUser,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  downloadMediaMessage
} = require("@whiskeysockets/baileys");

module.exports = {
  name: "gcstatus",
  aliases: ["gstatus"],
  category: "Group",
  description: "Post text, photo or video Group Status",

  async execute(sock, msg, args) {
    const groupJid = msg.key.remoteJid;

    if (!groupJid?.endsWith("@g.us")) {
      return sock.sendMessage(groupJid, {
        text: "❌ শুধু Group-এ ব্যবহার করা যাবে।"
      });
    }

    const text = args.join(" ").trim();
    const senderJid = jidNormalizedUser(sock.user?.id);

    try {
      const quoted =
        msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

      let quotedMessage = null;

      if (quoted) {
        quotedMessage = {
          key: {
            remoteJid: groupJid,
            fromMe: false,
            id:
              msg.message.extendedTextMessage.contextInfo
                .stanzaId || "STATUS_MEDIA",
            participant:
              msg.message.extendedTextMessage.contextInfo
                .participant
          },
          message: quoted
        };
      }

      let mediaType = null;

      if (quotedMessage?.message?.imageMessage) {
        mediaType = "image";
      } else if (quotedMessage?.message?.videoMessage) {
        mediaType = "video";
      }

      // ───────── TEXT STATUS ─────────
      if (!mediaType) {
        if (!text) {
          return sock.sendMessage(groupJid, {
            text:
              "⚙️ Usage:\n\n" +
              "• .gcstatus তোমার text\n" +
              "• Photo/Video-তে reply করে .gcstatus caption"
          });
        }

        const contextInfo = {
          forwardingScore: 0,
          featureEligibilities: {
            canBeReshared: true,
            canReceiveMultiReact: true
          },
          pairedMediaType: 0,
          isGroupStatus: true,
          statusAttributions: [
            {
              type: 6,
              groupStatus: {
                authorJid: senderJid
              }
            }
          ]
        };

        const content = {
          extendedTextMessage: {
            text,
            contextInfo
          }
        };

        const generated = generateWAMessageFromContent(
          groupJid,
          {
            groupStatusMessageV2: {
              message: content
            }
          },
          {
            userJid: senderJid
          }
        );

        await sock.relayMessage(
          groupJid,
          generated.message,
          {
            messageId: generated.key.id
          }
        );
        statusStore.add(groupJid, generated.key);

        return sock.sendMessage(groupJid, {
          text: "✅ 𝗚𝗥𝗢𝗨𝗣 𝗦𝗧𝗔𝗧𝗨𝗦\n\n📝 Text status posted."
        });
      }

      // ───────── DOWNLOAD REPLIED MEDIA ─────────
      const buffer = await downloadMediaMessage(
        quotedMessage,
        "buffer",
        {},
        {
          logger: sock.logger,
          reuploadRequest: sock.updateMediaMessage
        }
      );

      const mediaInput =
        mediaType === "image"
          ? { image: buffer }
          : { video: buffer };

      // ───────── PREPARE MEDIA ─────────
      const prepared = await prepareWAMessageMedia(
        mediaInput,
        {
          upload: sock.waUploadToServer
        }
      );

      const mediaMessage =
        prepared.imageMessage || prepared.videoMessage;

      if (!mediaMessage) {
        throw new Error("Media preparation failed");
      }

      mediaMessage.contextInfo = {
        forwardingScore: 0,
        featureEligibilities: {
          canBeReshared: true,
          canReceiveMultiReact: true
        },
        pairedMediaType: 0,
        isGroupStatus: true,
        statusAttributions: [
          {
            type: 6,
            groupStatus: {
              authorJid: senderJid
            }
          }
        ]
      };

      if (text) {
        mediaMessage.caption = text;
      }

      const generated = generateWAMessageFromContent(
        groupJid,
        {
          groupStatusMessageV2: {
            message:
              mediaType === "image"
                ? { imageMessage: mediaMessage }
                : { videoMessage: mediaMessage }
          }
        },
        {
          userJid: senderJid
        }
      );

      await sock.relayMessage(
        groupJid,
        generated.message,
        {
          messageId: generated.key.id
        }
      );

      statusStore.add(groupJid, generated.key);

      await sock.sendMessage(groupJid, {
        text:
          `✅ 𝗚𝗥𝗢𝗨𝗣 𝗦𝗧𝗔𝗧𝗨𝗦\n\n` +
          `${mediaType === "image" ? "🖼️ Photo" : "🎥 Video"} status posted.`
      });

    } catch (e) {
      console.log("❌ Group Status error:", e);

      await sock.sendMessage(groupJid, {
        text:
          "❌ Group Status পাঠানো যায়নি।\n\n" +
          `⚠️ ${e.message || "Unknown error"}`
      });
    }
  }
};
