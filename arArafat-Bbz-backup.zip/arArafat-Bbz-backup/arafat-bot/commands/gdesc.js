module.exports = {
  name: "gdesc",
  aliases: ["groupdesc", "description"],
  category: "Group",
  description: "Show group description",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    if (!jid?.endsWith("@g.us"))
      return sock.sendMessage(jid,{text:"❌ এই command শুধু Group-এ ব্যবহার করা যাবে।"});

    try {
      const meta = await sock.groupMetadata(jid);
      return sock.sendMessage(jid,{
        text:`╭──〔 𝗚𝗥𝗢𝗨𝗣 𝗗𝗘𝗦𝗖 〕──╮
│
├─ 𝗡ᴀᴍᴇ : ${meta.subject || "Unknown"}
│
├─ 𝗗ᴇsᴄʀɪᴘᴛɪᴏɴ
│  ${meta.desc || "No description set."}
│
╰────────────────────╯`
      });
    } catch(e) {
      return sock.sendMessage(jid,{text:`❌ Error: ${e.message}`});
    }
  }
};
