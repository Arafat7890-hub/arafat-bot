module.exports={
  name:"getpp",
  aliases:["profilepic","pp"],
  category:"Profile",
  description:"Get profile picture",
  async execute(sock,msg){
    const jid=msg.key.remoteJid;
    const c=msg.message?.extendedTextMessage?.contextInfo;
    const target=c?.participant||jid;
    try{
      const url=await sock.profilePictureUrl(target,"image");
      await sock.sendMessage(jid,{image:{url},caption:"🖼️ Profile Picture"});
    }catch(e){
      await sock.sendMessage(jid,{text:"❌ Profile picture পাওয়া যায়নি।"});
    }
  }
};
