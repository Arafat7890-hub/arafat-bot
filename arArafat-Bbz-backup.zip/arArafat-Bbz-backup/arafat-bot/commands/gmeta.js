module.exports = {
  name: "gmeta",
  aliases: ["metadata"],
  category: "Group",
  description: "Show detailed group metadata",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    if (!jid?.endsWith("@g.us"))
      return sock.sendMessage(jid, {
        text: "❌ শুধু Group-এ ব্যবহার করা যাবে।"
      });

    const meta = await sock.groupMetadata(jid);

    const admins = (meta.participants || []).filter(
      p => p.admin === "admin" || p.admin === "superadmin"
    ).length;

    const created = meta.creation
      ? new Date(meta.creation * 1000).toLocaleDateString("en-GB", {
          timeZone: "Asia/Dhaka",
          day: "2-digit",
          month: "long",
          year: "numeric"
        })
      : "Unknown";

    await sock.sendMessage(jid, {
      text: `╭━━━〔 ⚙️ 𝗚𝗥𝗢𝗨𝗣 𝗠𝗘𝗧𝗔 〕━━━╮
┃
┃ 🏷️ Name : ${meta.subject}
┃ 👥 Members : ${meta.participants?.length || 0}
┃ 👑 Admins : ${admins}
┃ 📅 Created : ${created}
┃ 🔐 Restricted : ${meta.restrict ? "Yes" : "No"}
┃ 📢 Announcement : ${meta.announce ? "Yes" : "No"}
┃ 📝 Description : ${meta.desc ? "Set" : "None"}
┃
╰━━━━━━━━━━━━━━━━━━━━╯`
    });
  }
};
