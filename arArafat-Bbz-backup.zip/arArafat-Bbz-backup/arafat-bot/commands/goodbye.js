const features = require("../lib/groupFeatures");
const { isGroupAdmin } = require("../lib/groupFeatureHelpers");

module.exports = {
  name: "goodbye",
  aliases: [],
  category: "GROUP",
  description: "Enable or disable goodbye messages",

  async execute(sock, msg, args) {
    const jid = msg.key.remoteJid;

    if (!jid?.endsWith("@g.us")) {
      return sock.sendMessage(jid, {
        text: "❌ This command works only in groups."
      });
    }

    if (!(await isGroupAdmin(sock, jid, msg))) {
      return sock.sendMessage(jid, {
        text: "❌ Only group admins can use this command."
      });
    }

    const mode = String(args[0] || "").toLowerCase();

    if (!["on", "off"].includes(mode)) {
      const current = features.get(jid)["goodbye"] ? "ON" : "OFF";

      return sock.sendMessage(jid, {
        text:
          "⚙️ GOODBYE\n\n" +
          "Status: " + current + "\n\n" +
          "Use:\n.goodbye on\n.goodbye off"
      });
    }

    features.set(jid, "goodbye", mode === "on");

    await sock.sendMessage(jid, {
      text:
        "╭─〔 GOODBYE 〕\n" +
        "├ Status: " + mode.toUpperCase() + "\n" +
        "╰────────────────"
    });
  }
};
