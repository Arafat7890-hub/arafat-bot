module.exports={
  name:"groupadd",
  aliases:["gadd"],
  category:"Group",
  description:"Add a member to group",
  async execute(sock,msg,args){
    const jid=msg.key.remoteJid;
    const number=(args[0]||"").replace(/\D/g,"");
    if(!jid?.endsWith("@g.us"))return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    if(!number)return sock.sendMessage(jid,{text:"❌ Use: `.groupadd 8801XXXXXXXXX`"});
    try{
      await sock.groupParticipantsUpdate(jid,[`${number}@s.whatsapp.net`],"add");
      await sock.sendMessage(jid,{text:"✅ Member add request sent."});
    }catch(e){await sock.sendMessage(jid,{text:"❌ Add failed: "+e.message});}
  }
};
