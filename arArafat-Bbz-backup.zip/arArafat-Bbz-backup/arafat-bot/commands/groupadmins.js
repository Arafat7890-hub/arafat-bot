module.exports={
  name:"groupadmins",
  aliases:["gadmins"],
  category:"Group",
  description:"List group admins",
  async execute(sock,msg){
    const jid=msg.key.remoteJid;
    if(!jid?.endsWith("@g.us"))
      return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    try{
      const meta=await sock.groupMetadata(jid);
      const admins=(meta.participants||[]).filter(p=>p.admin);
      const lines=admins.map((p,i)=>{
        const id=p.phoneNumber||p.id||"unknown";
        const role=p.admin==="superadmin"?"👑":"🛡️";
        return `${i+1}. ${role} ${id.split("@")[0]}`;
      });
      await sock.sendMessage(jid,{
        text:`🛡️ *GROUP ADMINS*\n\n${lines.join("\n")||"কোনো admin পাওয়া যায়নি।"}`
      });
    }catch(e){
      await sock.sendMessage(jid,{text:"❌ Admin list failed: "+e.message});
    }
  }
};
