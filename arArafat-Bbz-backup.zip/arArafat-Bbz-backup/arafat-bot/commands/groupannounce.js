module.exports={
  name:"groupannounce",
  aliases:["announce"],
  category:"Group",
  description:"Toggle admin-only messaging",
  async execute(sock,msg,args){
    const jid=msg.key.remoteJid;
    if(!jid?.endsWith("@g.us"))
      return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    const mode=(args[0]||"").toLowerCase();
    if(!["on","off"].includes(mode))
      return sock.sendMessage(jid,{text:"❌ Use: `.groupannounce on` / `.groupannounce off`"});
    try{
      await sock.groupSettingUpdate(
        jid,
        mode==="on"?"announcement":"not_announcement"
      );
      await sock.sendMessage(jid,{
        text:mode==="on"
          ?"🔒 শুধু Admin-রা message পাঠাতে পারবে।"
          :"🔓 সবাই message পাঠাতে পারবে।"
      });
    }catch(e){
      await sock.sendMessage(jid,{text:"❌ Setting update failed: "+e.message});
    }
  }
};
