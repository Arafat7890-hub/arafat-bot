module.exports = {
  name: "groupcard",
  aliases: ["gcard", "groupinfo"],
  category: "Group",
  description: "Premium group information card",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    if (!jid?.endsWith("@g.us")) {
      return sock.sendMessage(jid, {
        text: "❌ এই command শুধু Group-এ ব্যবহার করা যাবে।"
      });
    }

    try {
      const meta = await sock.groupMetadata(jid);
      const members = meta.participants || [];

      const admins = members.filter(p =>
        p.admin === "admin" ||
        p.admin === "superadmin" ||
        p.isAdmin ||
        p.isSuperAdmin
      );

      const owner = String(
        meta.ownerPn ||
        meta.owner ||
        meta.subjectOwnerPn ||
        meta.subjectOwner ||
        "Unknown"
      )
        .split("@")[0]
        .split(":")[0]
        .replace(/\D/g, "");

      const groupName = String(meta.subject || "Unknown")
        .normalize("NFKC")
        .replace(/[\u2661\u20DD\uFFFD]/g, "")
        .replace(/\s{2,}/g, " ")
        .trim()
        .slice(0, 28);

      const text =
`╭──〔 𝗔𝗥𝗔𝗙𝗔𝗧 𝗚𝗥𝗢𝗨𝗣 〕──╮
│
├─ 𝗡ᴀᴍᴇ       : ${groupName || "Unknown"}
├─ 𝗠ᴇᴍʙᴇʀs    : ${meta.size ?? members.length}
├─ 𝗔ᴅᴍɪɴs     : ${admins.length}
├─ 𝗢ᴡɴᴇʀ      : ${owner || "Unknown"}
├─ 𝗚ʀᴏᴜᴘ 𝗜ᴅ   : ${jid.split("@")[0]}
│
├─ 𝗠ᴇssᴀɢᴇs   : ${meta.announce === true ? "Admins Only" : "Everyone"}
├─ 𝗦ᴇᴛᴛɪɴɢs   : ${meta.restrict === true ? "Admins Only" : "Everyone"}
├─ 𝗠ᴇᴍʙᴇʀ 𝗔ᴅᴅ: ${meta.memberAddMode === true ? "Everyone" : "Admins"}
├─ 𝗔ᴘᴘʀᴏᴠᴀʟ  : ${meta.joinApprovalMode === true ? "ON" : "OFF"}
│
╰────────────────────────────╯`;

      return sock.sendMessage(jid, { text });
    } catch (e) {
      return sock.sendMessage(jid, {
        text: `❌ Group Card করা যায়নি.\n\n⚠️ ${e.message}`
      });
    }
  }
};
