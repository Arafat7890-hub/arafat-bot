module.exports={
  name:"groupcreate",
  aliases:["gcreate"],
  category:"Group",
  description:"Create a group",
  async execute(sock,msg,args){
    const jid=msg.key.remoteJid;
    const subject=args.join(" ").trim();
    if(!subject)return sock.sendMessage(jid,{text:"❌ Use: `.groupcreate Group Name`"});
    try{
      const group=await sock.groupCreate(subject,[]);
      await sock.sendMessage(jid,{text:`✅ Group created.\n\n${group?.id||""}`});
    }catch(e){await sock.sendMessage(jid,{text:"❌ Create failed: "+e.message});}
  }
};
