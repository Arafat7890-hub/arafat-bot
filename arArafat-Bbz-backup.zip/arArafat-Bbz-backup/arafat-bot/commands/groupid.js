module.exports = {
  name: "groupid",
  aliases: ["gid", "gcjid"],
  category: "Group",
  description: "Show group ID",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    if (!jid?.endsWith("@g.us"))
      return sock.sendMessage(jid,{text:"❌ এই command শুধু Group-এ ব্যবহার করা যাবে।"});

    return sock.sendMessage(jid,{
      text:`╭──〔 𝗚𝗥𝗢𝗨𝗣 𝗜𝗗 〕──╮
│
├─ 𝗝𝗜𝗗 : ${jid}
│
╰────────────────────╯`
    });
  }
};
