module.exports = {
  name: "groupinfo",
  aliases: ["ginfo", "group"],
  category: "Group",
  description: "Show detailed group information",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    if (!jid || !jid.endsWith("@g.us")) {
      return sock.sendMessage(jid, {
        text: "❌ এই command শুধু WhatsApp Group-এ ব্যবহার করা যাবে।"
      });
    }

    try {
      const metadata = await sock.groupMetadata(jid);
      const participants = metadata.participants || [];

      const admins = participants.filter(p => p.admin);
      const owner = metadata.owner
        ? `@${metadata.owner.split("@")[0]}`
        : "Unknown";

      const announce = metadata.announce
        ? "🔒 শুধু Admin"
        : "💬 সবাই";

      const restrict = metadata.restrict
        ? "🔒 শুধু Admin"
        : "✏️ সবাই";

      const text = `╭━━━〔 ⚡ 𝗔𝗥𝗔𝗙𝗔𝗧 𝗕𝗕𝗭 〕━━━╮
┃
┃ 🏷️ 𝗚𝗿𝗼𝘂𝗽 : ${metadata.subject || "Unknown"}
┃ 👥 𝗠𝗲𝗺𝗯𝗲𝗿𝘀 : ${participants.length}
┃ 👑 𝗔𝗱𝗺𝗶𝗻𝘀 : ${admins.length}
┃ 👤 𝗢𝘄𝗻𝗲𝗿 : ${owner}
┃
┃ 💬 𝗠𝗲𝘀𝘀𝗮𝗴𝗲 : ${announce}
┃ ⚙️ 𝗘𝗱𝗶𝘁 𝗚𝗿𝗼𝘂𝗽 : ${restrict}
┃
╰━━━━━━━━━━━━━━━━━━━━╯`;

      const mentions = metadata.owner ? [metadata.owner] : [];

      await sock.sendMessage(jid, {
        text,
        mentions
      });

    } catch (e) {
      console.log("❌ GroupInfo error:", e.message);

      await sock.sendMessage(jid, {
        text: "❌ Group information পাওয়া যায়নি।"
      });
    }
  }
};
