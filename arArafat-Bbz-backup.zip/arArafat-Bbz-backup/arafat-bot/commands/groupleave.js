module.exports={
  name:"groupleave",
  aliases:["gcleave"],
  category:"Group",
  description:"Leave current group",
  async execute(sock,msg){
    const jid=msg.key.remoteJid;
    if(!jid?.endsWith("@g.us"))return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    try{
      await sock.groupLeave(jid);
    }catch(e){await sock.sendMessage(jid,{text:"❌ Leave failed: "+e.message});}
  }
};
