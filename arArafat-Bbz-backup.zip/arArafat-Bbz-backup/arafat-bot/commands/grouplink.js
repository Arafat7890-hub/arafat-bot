module.exports = {
  name: "grouplink",
  aliases: ["glink"],
  category: "Admin",
  description: "Get group invite link",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    if (!jid?.endsWith("@g.us"))
      return sock.sendMessage(jid, { text: "❌ শুধু Group-এ ব্যবহার করা যাবে।" });

    const meta = await sock.groupMetadata(jid);
    const sender = msg.key.participant || jid;
    const me = meta.participants.find(p => p.id === sender);

    if (!me?.admin)
      return sock.sendMessage(jid, { text: "❌ শুধু Group Admin ব্যবহার করতে পারবে।" });

    try {
      const code = await sock.groupInviteCode(jid);

      await sock.sendMessage(jid, {
        text: `🔗 𝗚𝗥𝗢𝗨𝗣 𝗟𝗜𝗡𝗞\n\nhttps://chat.whatsapp.com/${code}`
      });
    } catch {
      await sock.sendMessage(jid, { text: "❌ Group link পাওয়া যায়নি।" });
    }
  }
};
