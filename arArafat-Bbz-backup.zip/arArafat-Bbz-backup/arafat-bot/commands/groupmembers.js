module.exports={
  name:"groupmembers",
  aliases:["gmembers"],
  category:"Group",
  description:"List group members",
  async execute(sock,msg){
    const jid=msg.key.remoteJid;
    if(!jid?.endsWith("@g.us"))
      return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    try{
      const meta=await sock.groupMetadata(jid);
      const lines=(meta.participants||[]).map((p,i)=>{
        const id=p.phoneNumber||p.id||"unknown";
        const role=p.admin==="superadmin"?"👑":p.admin==="admin"?"🛡️":"👤";
        return `${i+1}. ${role} ${id.split("@")[0]}`;
      });
      await sock.sendMessage(jid,{
        text:`👥 *${meta.subject}*\n\n${lines.join("\n")}`
      });
    }catch(e){
      await sock.sendMessage(jid,{text:"❌ Members fetch failed: "+e.message});
    }
  }
};
