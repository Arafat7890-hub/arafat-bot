module.exports={
  name:"groupmention",
  aliases:["mentionall"],
  category:"Group",
  description:"Mention all group members",
  async execute(sock,msg,args){
    const jid=msg.key.remoteJid;
    if(!jid?.endsWith("@g.us"))return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    const meta=await sock.groupMetadata(jid);
    const members=meta.participants||[];
    const text=args.join(" ").trim()||"📢 Attention everyone!";
    const mentions=members.map(p=>p.id);
    const lines=members.map(p=>`@${String(p.id).split("@")[0]}`).join(" ");
    await sock.sendMessage(jid,{text:`${text}\n\n${lines}`,mentions});
  }
};
