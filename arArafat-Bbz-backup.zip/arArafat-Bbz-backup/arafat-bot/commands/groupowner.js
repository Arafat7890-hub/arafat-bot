module.exports={
  name:"groupowner",
  aliases:["gcreator"],
  category:"Group",
  description:"Show group creator",
  async execute(sock,msg){
    const jid=msg.key.remoteJid;
    if(!jid?.endsWith("@g.us"))
      return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    try{
      const meta=await sock.groupMetadata(jid);
      const owner=meta.owner||meta.subjectOwner;
      const text=owner
        ? `👑 Group Owner\n\n${String(owner).split("@")[0]}`
        : "❌ Group owner information পাওয়া যায়নি।";
      await sock.sendMessage(jid,{text});
    }catch(e){
      await sock.sendMessage(jid,{text:"❌ Owner fetch failed: "+e.message});
    }
  }
};
