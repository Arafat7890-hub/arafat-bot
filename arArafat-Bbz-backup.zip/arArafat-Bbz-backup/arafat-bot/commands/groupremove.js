module.exports={
  name:"groupremove",
  aliases:["gremove"],
  category:"Group",
  description:"Remove a member from group",
  async execute(sock,msg,args){
    const jid=msg.key.remoteJid;
    const number=(args[0]||"").replace(/\D/g,"");
    if(!jid?.endsWith("@g.us"))return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    if(!number)return sock.sendMessage(jid,{text:"❌ Use: `.groupremove 8801XXXXXXXXX`"});
    try{
      await sock.groupParticipantsUpdate(jid,[`${number}@s.whatsapp.net`],"remove");
      await sock.sendMessage(jid,{text:"✅ Member removal requested."});
    }catch(e){await sock.sendMessage(jid,{text:"❌ Remove failed: "+e.message});}
  }
};
