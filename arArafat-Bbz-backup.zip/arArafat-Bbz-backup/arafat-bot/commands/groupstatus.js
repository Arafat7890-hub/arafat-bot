module.exports={
  name:"groupstatus",
  aliases:["gcstatus2"],
  category:"Group",
  description:"Send a group status message",
  async execute(sock,msg,args){
    const jid=msg.key.remoteJid;
    if(!jid?.endsWith("@g.us"))return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    const text=args.join(" ").trim();
    if(!text)return sock.sendMessage(jid,{text:"❌ Text দাও।"});
    try{
      await sock.sendMessage(jid,{text,groupStatus:true});
    }catch(e){await sock.sendMessage(jid,{text:"❌ Failed: "+e.message});}
  }
};
