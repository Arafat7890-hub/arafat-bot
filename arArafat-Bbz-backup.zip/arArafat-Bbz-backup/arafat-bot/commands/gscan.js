const { jidNormalizedUser } = require("@whiskeysockets/baileys");

module.exports = {
  name: "gscan",
  aliases: ["groupscan", "ghealth"],
  category: "Group",
  description: "Professional group security and health scan",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    if (!jid?.endsWith("@g.us")) {
      return sock.sendMessage(jid, {
        text: "❌ এই command শুধু Group-এ ব্যবহার করা যাবে।"
      });
    }

    try {
      const meta = await sock.groupMetadata(jid);
      const participants = meta.participants || [];

      const admins = participants.filter(p =>
        p.admin === "admin" ||
        p.admin === "superadmin" ||
        p.isAdmin ||
        p.isSuperAdmin
      );

      const me = jidNormalizedUser(sock.user?.id || "");

      const botMember = participants.find(p =>
        jidNormalizedUser(p.id || "") === me ||
        jidNormalizedUser(p.phoneNumber || "") === me
      );

      const botAdmin =
        !!botMember &&
        (
          botMember.admin === "admin" ||
          botMember.admin === "superadmin" ||
          botMember.isAdmin ||
          botMember.isSuperAdmin
        );

      const checks = [
        botAdmin,
        admins.length > 0,
        !!meta.subject,
        meta.desc !== undefined,
        meta.size !== undefined,
        meta.joinApprovalMode !== undefined,
        meta.memberAddMode !== undefined
      ];

      const health = Math.round(
        (checks.filter(Boolean).length / checks.length) * 100
      );

      const healthText =
        health >= 85 ? "🟢 EXCELLENT" :
        health >= 65 ? "🟡 GOOD" :
        "🔴 NEEDS ATTENTION";

      const owner =
        meta.ownerPn ||
        meta.owner ||
        meta.subjectOwnerPn ||
        meta.subjectOwner ||
        "";

      const ownerNumber = String(owner)
        .split("@")[0]
        .split(":")[0]
        .replace(/\D/g, "");

      const addMode =
        meta.memberAddMode === true
          ? "Everyone"
          : meta.memberAddMode === false
            ? "Admins"
            : "Unknown";

      const joinApproval =
        meta.joinApprovalMode === true ? "ON" :
        meta.joinApprovalMode === false ? "OFF" :
        "Unknown";

      const announce =
        meta.announce === true ? "Admins Only" :
        meta.announce === false ? "Everyone" :
        "Unknown";

      const settings =
        meta.restrict === true ? "Admins Only" :
        meta.restrict === false ? "Everyone" :
        "Unknown";

      // Keep dynamic group data plain and safe.
      const clean = (value, max = 22) => {
        let text = String(value ?? "Unknown")
          .replace(/[\r\n]/g, " ")
          .replace(/\uFFFD/g, "");

        if (text.length > max) {
          text = text.slice(0, max - 3) + "...";
        }

        return text;
      };

      const groupName = clean(
        String(meta.subject || "Unknown").normalize("NFKC"),
        22
      );

      const text =
`╭──〔 𝗔𝗥𝗔𝗙𝗔𝗧 𝗚𝗥𝗢𝗨𝗣 𝗦𝗖𝗔𝗡 〕──╮
│
├─ 𝗚ʀᴏᴜᴘ       : ${groupName}
├─ 𝗠ᴇᴍʙᴇʀs     : ${meta.size ?? participants.length}
├─ 𝗔ᴅᴍɪɴs      : ${admins.length}
├─ 𝗢ᴡɴᴇʀ       : ${ownerNumber || "Unknown"}
├─ 𝗕ᴏᴛ 𝗔ᴅᴍɪɴ   : ${botAdmin ? "YES ✓" : "NO ✗"}
│
├─ 𝗠ᴇssᴀɢᴇs    : ${clean(announce)}
├─ 𝗦ᴇᴛᴛɪɴɢs    : ${clean(settings)}
├─ 𝗠ᴇᴍʙᴇʀ 𝗔ᴅᴅ : ${clean(addMode)}
├─ 𝗔ᴘᴘʀᴏᴠᴀʟ   : ${clean(joinApproval)}
├─ 𝗗ᴇsᴄʀɪᴘᴛɪᴏɴ: ${meta.desc ? "Available" : "None"}
│
╰────────────────────────────╯

╭──〔 𝗚𝗥𝗢𝗨𝗣 𝗛𝗘𝗔𝗟𝗧𝗛 〕──╮
│
├─ 𝗦ᴄᴏʀᴇ       : ${health}%
├─ 𝗦ᴛᴀᴛᴜs      : ${healthText}
│
╰────────────────────────────╯`;

      return sock.sendMessage(jid, { text });

    } catch (e) {
      console.log("❌ GSCAN ERROR:", e);

      return sock.sendMessage(jid, {
        text:
          "❌ Group Scan করা যায়নি.\n\n" +
          `⚠️ ${e.message || "Unknown error"}`
      });
    }
  }
};
