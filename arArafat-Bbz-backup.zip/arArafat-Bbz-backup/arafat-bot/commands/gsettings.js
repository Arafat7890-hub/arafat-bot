module.exports = {
  name: "gsettings",
  aliases: ["groupsettings", "gset"],
  category: "Group",
  description: "Group settings dashboard",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    if (!jid?.endsWith("@g.us")) {
      return sock.sendMessage(jid, {
        text: "❌ এই command শুধু Group-এ ব্যবহার করা যাবে।"
      });
    }

    try {
      const meta = await sock.groupMetadata(jid);

      const yesNo = value =>
        value === true ? "ON" :
        value === false ? "OFF" :
        "Unknown";

      const text =
`╭──〔 𝗚𝗥𝗢𝗨𝗣 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦 〕──╮
│
├─ 𝗠ᴇssᴀɢᴇs    : ${meta.announce === true ? "Admins Only" : "Everyone"}
├─ 𝗘ᴅɪᴛ 𝗜ɴғᴏ   : ${meta.restrict === true ? "Admins Only" : "Everyone"}
├─ 𝗠ᴇᴍʙᴇʀ 𝗔ᴅᴅ : ${meta.memberAddMode === true ? "Everyone" : "Admins"}
├─ 𝗔ᴘᴘʀᴏᴠᴀʟ    : ${yesNo(meta.joinApprovalMode)}
├─ 𝗗ᴇsᴄʀɪᴘᴛɪᴏɴ: ${meta.desc ? "Available" : "None"}
│
╰────────────────────────────╯`;

      return sock.sendMessage(jid, { text });
    } catch (e) {
      return sock.sendMessage(jid, {
        text: `❌ Group Settings error.\n\n⚠️ ${e.message}`
      });
    }
  }
};
