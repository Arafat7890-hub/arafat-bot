module.exports = {
  name: "gstats",
  aliases: ["groupstats", "gst"],
  category: "Group",
  description: "Live group statistics",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    if (!jid?.endsWith("@g.us")) {
      return sock.sendMessage(jid, {
        text: "❌ এই command শুধু Group-এ ব্যবহার করা যাবে।"
      });
    }

    try {
      const meta = await sock.groupMetadata(jid);
      const members = meta.participants || [];

      const admins = members.filter(p =>
        p.admin === "admin" ||
        p.admin === "superadmin" ||
        p.isAdmin ||
        p.isSuperAdmin
      );

      const superAdmins = members.filter(p =>
        p.admin === "superadmin" ||
        p.isSuperAdmin
      );

      const botId = String(sock.user?.id || "")
        .split(":")[0]
        .split("@")[0];

      const bot = members.find(p =>
        String(p.id || "").split("@")[0] === botId ||
        String(p.phoneNumber || "").split("@")[0] === botId
      );

      const botAdmin =
        !!bot &&
        (
          bot.admin === "admin" ||
          bot.admin === "superadmin" ||
          bot.isAdmin ||
          bot.isSuperAdmin
        );

      const text =
`╭──〔 𝗚𝗥𝗢𝗨𝗣 𝗦𝗧𝗔𝗧𝗦 〕──╮
│
├─ 𝗠ᴇᴍʙᴇʀs    : ${members.length}
├─ 𝗔ᴅᴍɪɴs     : ${admins.length}
├─ 𝗢ᴡɴᴇʀ/𝗦ᴜᴘᴇʀ: ${superAdmins.length}
├─ 𝗕ᴏᴛ 𝗔ᴅᴍɪɴ  : ${botAdmin ? "YES ✓" : "NO ✗"}
│
├─ 𝗠ᴇssᴀɢᴇs   : ${meta.announce === true ? "Admins Only" : "Everyone"}
├─ 𝗘ᴅɪᴛ 𝗜ɴғᴏ  : ${meta.restrict === true ? "Admins Only" : "Everyone"}
├─ 𝗠ᴇᴍʙᴇʀ 𝗔ᴅᴅ: ${meta.memberAddMode === true ? "Everyone" : "Admins"}
├─ 𝗔ᴘᴘʀᴏᴠᴀʟ  : ${meta.joinApprovalMode === true ? "ON" : "OFF"}
│
╰────────────────────────╯`;

      return sock.sendMessage(jid, { text });
    } catch (e) {
      return sock.sendMessage(jid, {
        text: `❌ GStats error.\n\n⚠️ ${e.message}`
      });
    }
  }
};
