module.exports={name:"hasmedia2",aliases:["mediaexists"],category:"Utility",description:"Check media",async execute(sock,msg){
const jid=msg.key.remoteJid,m=msg.message||{};
const media=["imageMessage","videoMessage","audioMessage","documentMessage","stickerMessage"];
const yes=media.some(x=>!!m[x]);
await sock.sendMessage(jid,{text:yes?"📦 Media আছে।":"📝 Media নেই।"});
}};
