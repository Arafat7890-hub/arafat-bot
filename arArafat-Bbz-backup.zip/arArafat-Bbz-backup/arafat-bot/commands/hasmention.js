module.exports={name:"hasmention",aliases:["mentioned"],category:"Utility",description:"Check mentions",async execute(sock,msg){
const jid=msg.key.remoteJid,m=msg.message?.extendedTextMessage?.contextInfo;
await sock.sendMessage(jid,{text:(m?.mentionedJid?.length)?"✅ Mention আছে।":"❌ Mention নেই।"});
}};
