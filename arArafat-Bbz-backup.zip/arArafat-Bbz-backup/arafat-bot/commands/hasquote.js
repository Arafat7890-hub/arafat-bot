module.exports={name:"hasquote",aliases:["quoted"],category:"Utility",description:"Check quoted message",async execute(sock,msg){
const jid=msg.key.remoteJid,q=msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
await sock.sendMessage(jid,{text:q?"✅ Quoted message আছে।":"❌ Quoted message নেই।"});
}};
