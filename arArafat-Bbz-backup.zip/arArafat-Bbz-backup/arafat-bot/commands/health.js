const os = require("os");

module.exports = {
  name: "health",
  aliases: ["systemhealth", "status"],
  category: "System",
  description: "Bot system health",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    const mem = process.memoryUsage();
    const total = os.totalmem() / 1024 / 1024;
    const free = os.freemem() / 1024 / 1024;
    const used = total - free;

    const uptime = process.uptime();

    const text =
`╭──〔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗛𝗘𝗔𝗟𝗧𝗛 〕──╮
│
├─ 𝗦ᴛᴀᴛᴜs      : ONLINE ✓
├─ 𝗣ʀᴏᴄᴇss     : ${Math.round(mem.rss / 1024 / 1024)} MB
├─ 𝗦ʏsᴛᴇᴍ      : ${Math.round(used)} / ${Math.round(total)} MB
├─ 𝗨ᴘᴛɪᴍᴇ      : ${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m
├─ 𝗡ᴏᴅᴇ        : ${process.version}
├─ 𝗖ᴘᴜ         : ${os.cpus()[0]?.model || "Unknown"}
│
╰────────────────────────────╯`;

    return sock.sendMessage(jid, { text });
  }
};
