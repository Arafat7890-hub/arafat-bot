module.exports = {
  name: "help",
  aliases: ["h", "commands"],
  category: "General",
  description: "Show basic command help",

  async execute(sock, msg) {
    await sock.sendMessage(msg.key.remoteJid, {
      text:
        "╭━━━〔 🤖 ʜᴇʟᴘ 〕━━━╮\n" +
        "┃\n" +
        "┃ 📌 .menu — Bot menu\n" +
        "┃ 🏓 .ping — Check response\n" +
        "┃ ⏱️ .runtime — Bot uptime\n" +
        "┃ 👤 .owner — Owner info\n" +
        "┃ 🆔 .id — Your ID\n" +
        "┃\n" +
        "╰━━━━━━━━━━━━━━━━╯"
    });
  }
};
