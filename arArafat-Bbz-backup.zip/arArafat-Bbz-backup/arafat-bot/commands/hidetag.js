module.exports = {
  name: "hidetag",
  aliases: ["ht", "silenttag"],
  category: "Group",
  description: "Mention all group members without showing tags",

  async execute(sock, msg, args) {
    const jid = msg.key.remoteJid;

    if (!jid || !jid.endsWith("@g.us")) {
      return sock.sendMessage(jid, {
        text: "❌ এই command শুধু Group-এ ব্যবহার করা যাবে।"
      });
    }

    const metadata = await sock.groupMetadata(jid);
    const participants = metadata.participants || [];
    const mentions = participants.map(p => p.id);

    const text = args.length
      ? args.join(" ")
      : "📢 Attention everyone!";

    await sock.sendMessage(jid, {
      text,
      mentions
    });
  }
};
