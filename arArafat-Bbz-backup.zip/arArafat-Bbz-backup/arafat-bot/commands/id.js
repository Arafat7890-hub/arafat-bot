module.exports = {
  name: "id",
  aliases: ["chatid"],
  category: "Info",
  description: "Show current chat ID",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    await sock.sendMessage(jid, {
      text: `🆔 ᴄʜᴀᴛ ɪᴅ\n\n➤ ${jid}`
    });
  }
};
