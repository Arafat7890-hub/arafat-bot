module.exports={
  name:"idinfo",
  aliases:["jidinfo"],
  category:"Utility",
  description:"Show current chat ID",
  async execute(sock,msg){
    const jid=msg.key.remoteJid;
    await sock.sendMessage(jid,{text:`🆔 Chat ID\n\n${jid}`});
  }
};
