module.exports = {
  name: "invite",
  aliases: ["grouplink", "gclink"],
  category: "Group",
  description: "Get group invite link",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    if (!jid?.endsWith("@g.us"))
      return sock.sendMessage(jid,{text:"❌ এই command শুধু Group-এ ব্যবহার করা যাবে।"});

    try {
      const meta = await sock.groupMetadata(jid);
      const bot = (meta.participants || []).find(p => {
        const me = String(sock.user?.id || "").split(":")[0].split("@")[0];
        const id = String(p.id || "").split("@")[0].split(":")[0];
        const pn = String(p.phoneNumber || "").split("@")[0].split(":")[0];
        return id === me || pn === me;
      });

      const isAdmin =
        bot &&
        (
          bot.admin === "admin" ||
          bot.admin === "superadmin" ||
          bot.isAdmin ||
          bot.isSuperAdmin
        );

      if (!isAdmin)
        return sock.sendMessage(jid,{
          text:"❌ Bot admin না হওয়ায় invite link নেওয়া যাচ্ছে না।"
        });

      const code = await sock.groupInviteCode(jid);

      return sock.sendMessage(jid,{
        text:`╭──〔 𝗚𝗥𝗢𝗨𝗣 𝗜𝗡𝗩𝗜𝗧𝗘 〕──╮
│
├─ 𝗟ɪɴᴋ:
│
│ https://chat.whatsapp.com/${code}
│
╰────────────────────────╯`
      });
    } catch(e) {
      return sock.sendMessage(jid,{
        text:`❌ Invite link পাওয়া যায়নি.\n\n⚠️ ${e.message}`
      });
    }
  }
};
