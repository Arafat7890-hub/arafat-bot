module.exports={
  name:"inviteinfo",
  aliases:["joininfo"],
  category:"Group",
  description:"Get information from an invite code",
  async execute(sock,msg,args){
    const jid=msg.key.remoteJid;
    const input=args[0]||"";
    const m=input.match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/i);
    const code=m?.[1]||input;
    if(!code)return sock.sendMessage(jid,{text:"❌ Invite link/code দাও।"});
    try{
      const meta=await sock.groupGetInviteInfo(code);
      await sock.sendMessage(jid,{text:
`📋 GROUP INVITE INFO

👥 Name: ${meta.subject||"Unknown"}
👤 Members: ${meta.size||meta.participants?.length||"Unknown"}
🆔 ID: ${meta.id||"Unknown"}`
      });
    }catch(e){await sock.sendMessage(jid,{text:"❌ Invite info পাওয়া যায়নি: "+e.message});}
  }
};
