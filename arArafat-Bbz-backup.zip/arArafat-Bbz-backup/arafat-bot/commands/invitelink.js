module.exports={
  name:"invitelink",
  aliases:["gclink","getlink"],
  category:"Group",
  description:"Get group invite link",
  async execute(sock,msg){
    const jid=msg.key.remoteJid;
    if(!jid?.endsWith("@g.us"))
      return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    try{
      const code=await sock.groupInviteCode(jid);
      if(!code) throw new Error("Invite code পাওয়া যায়নি");
      await sock.sendMessage(jid,{
        text:`🔗 *GROUP INVITE LINK*\n\nhttps://chat.whatsapp.com/${code}`
      });
    }catch(e){
      await sock.sendMessage(jid,{text:"❌ Invite link পাওয়া যায়নি: "+e.message});
    }
  }
};
