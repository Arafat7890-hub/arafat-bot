module.exports={name:"isforwarded",aliases:["forwarded"],category:"Utility",description:"Check forwarded message",async execute(sock,msg){
const jid=msg.key.remoteJid,m=msg.message?.extendedTextMessage;
await sock.sendMessage(jid,{text:m?.contextInfo?.isForwarded?"↪️ Forwarded message":"📩 Not forwarded"});
}};
