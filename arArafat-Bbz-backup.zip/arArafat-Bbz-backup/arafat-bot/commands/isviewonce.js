module.exports={name:"isviewonce",aliases:["viewonceinfo"],category:"Utility",description:"Check view once message",async execute(sock,msg){
const jid=msg.key.remoteJid,m=msg.message||{};
const yes=!!(m.viewOnceMessage||m.viewOnceMessageV2||m.viewOnceMessageV2Extension);
await sock.sendMessage(jid,{text:yes?"👁️ View Once message":"📩 Normal message"});
}};
