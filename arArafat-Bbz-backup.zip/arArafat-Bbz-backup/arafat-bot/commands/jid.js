module.exports = {
  name: "jid",
  aliases: ["myjid"],
  category: "General",
  description: "Show current chat JID",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid || "Unknown";

    await sock.sendMessage(jid, {
      text:
        "╭━━━〔 🪪 ᴊɪᴅ 〕━━━╮\n" +
        "┃\n" +
        `┃ 🔹 ${jid}\n` +
        "┃\n" +
        "╰━━━━━━━━━━━━━━╯"
    });
  }
};
