module.exports={
  name:"join",
  aliases:["joingroup"],
  category:"Group",
  description:"Join a group using an invite link",
  async execute(sock,msg,args){
    const jid=msg.key.remoteJid;
    const input=args[0]||"";
    const match=input.match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/i);
    const code=match?.[1]||input.trim();
    if(!code)
      return sock.sendMessage(jid,{text:"❌ Use: `.join https://chat.whatsapp.com/INVITECODE`"});
    try{
      const groupJid=await sock.groupAcceptInvite(code);
      await sock.sendMessage(jid,{text:`✅ Group joined successfully.\n\n${groupJid||""}`});
    }catch(e){
      await sock.sendMessage(jid,{text:"❌ Join failed: "+e.message});
    }
  }
};
