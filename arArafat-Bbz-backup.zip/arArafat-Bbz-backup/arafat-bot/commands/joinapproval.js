module.exports={
  name:"joinapproval",
  aliases:["approval"],
  category:"Group",
  description:"Toggle join approval",
  async execute(sock,msg,args){
    const jid=msg.key.remoteJid;
    if(!jid?.endsWith("@g.us"))return sock.sendMessage(jid,{text:"❌ শুধু Group-এ ব্যবহার করা যাবে।"});
    const mode=(args[0]||"").toLowerCase();
    if(!["on","off"].includes(mode))return sock.sendMessage(jid,{text:"❌ Use: `.joinapproval on|off`"});
    try{
      await sock.groupJoinApprovalMode(jid,mode);
      await sock.sendMessage(jid,{text:`✅ Join approval: ${mode.toUpperCase()}`});
    }catch(e){await sock.sendMessage(jid,{text:"❌ Failed: "+e.message});}
  }
};
