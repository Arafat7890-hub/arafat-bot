module.exports={name:"json",aliases:["inspect"],category:"Utility",description:"Inspect replied message",async execute(sock,msg){
const jid=msg.key.remoteJid;
const m=msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
if(!m)return sock.sendMessage(jid,{text:"❌ আগে কোনো message-এ reply করো।"});
await sock.sendMessage(jid,{text:"```"+JSON.stringify(m,null,2).slice(0,6000)+"```"});
}};
