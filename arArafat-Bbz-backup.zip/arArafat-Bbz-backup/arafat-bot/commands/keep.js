module.exports={
  name:"keep",
  aliases:["keepmsg"],
  category:"Message",
  description:"Keep a replied disappearing message",
  async execute(sock,msg){
    const jid=msg.key.remoteJid;
    const c=msg.message?.extendedTextMessage?.contextInfo;
    if(!c?.stanzaId)return sock.sendMessage(jid,{text:"❌ আগে message-এ reply করো।"});
    try{
      await sock.sendMessage(jid,{
        keep:{
          key:{remoteJid:jid,id:c.stanzaId,participant:c.participant,fromMe:false},
          type:1
        }
      });
      await sock.sendMessage(jid,{text:"📌 Message kept."});
    }catch(e){await sock.sendMessage(jid,{text:"❌ Keep failed: "+e.message});}
  }
};
