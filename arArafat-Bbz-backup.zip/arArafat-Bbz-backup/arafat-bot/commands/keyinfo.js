module.exports={name:"keyinfo",aliases:["msgkey"],category:"Utility",description:"Show message key information",async execute(sock,msg){
const jid=msg.key.remoteJid;
await sock.sendMessage(jid,{text:`🔑 MESSAGE KEY\n\nID: ${msg.key?.id||"N/A"}\nRemote: ${msg.key?.remoteJid||"N/A"}\nParticipant: ${msg.key?.participant||"N/A"}\nFromMe: ${!!msg.key?.fromMe}`});
}};
