module.exports = {
  name: "kick",
  aliases: ["remove"],
  category: "Admin",
  description: "Remove a mentioned or replied group member",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    if (!jid || !jid.endsWith("@g.us")) {
      return sock.sendMessage(jid, {
        text: "❌ এই command শুধু Group-এ ব্যবহার করা যাবে।"
      });
    }

    const metadata = await sock.groupMetadata(jid);
    const sender =
      msg.key.participant ||
      msg.key.remoteJid;

    const senderInfo = metadata.participants.find(
      p => p.id === sender
    );

    if (!senderInfo?.admin) {
      return sock.sendMessage(jid, {
        text: "❌ শুধু Group Admin এই command ব্যবহার করতে পারবে।"
      });
    }

    const context =
      msg.message?.extendedTextMessage?.contextInfo ||
      msg.message?.conversation?.contextInfo ||
      {};

    const mentioned =
      Array.isArray(context.mentionedJid)
        ? context.mentionedJid
        : [];

    const replied = context.participant;

    const target = mentioned[0] || replied;

    if (!target) {
      return sock.sendMessage(jid, {
        text:
          "⚙️ যাকে kick করতে চাও তাকে mention করে `.kick` দাও,\n" +
          "অথবা তার message-এ reply করে `.kick` দাও।"
      });
    }

    const targetInfo = metadata.participants.find(
      p => p.id === target
    );

    if (!targetInfo) {
      return sock.sendMessage(jid, {
        text: "❌ Member পাওয়া যায়নি।"
      });
    }

    if (targetInfo.admin) {
      return sock.sendMessage(jid, {
        text: "❌ Admin-কে kick করা যাবে না।"
      });
    }

    try {
      const result = await sock.groupParticipantsUpdate(
        jid,
        [targetInfo.id],
        "remove"
      );

      const failed = result?.some(
        r => String(r.status) !== "200"
      );

      if (failed) {
        return sock.sendMessage(jid, {
          text: "❌ Kick failed. Bot-কে Group Admin করা আছে কিনা দেখো।"
        });
      }

      await sock.sendMessage(jid, {
        text: "✅ 𝗞𝗜𝗖𝗞\n\n👤 Member successfully removed."
      });
    } catch (e) {
      console.log("❌ Kick error:", e.message);

      await sock.sendMessage(jid, {
        text: "❌ Kick failed. Bot-কে Group Admin করা আছে কিনা দেখো।"
      });
    }
  }
};
