module.exports = {
  name: "kickall",
  aliases: ["removeall"],
  category: "Admin",
  description: "Remove non-admin group members",

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    if (!jid || !jid.endsWith("@g.us")) {
      return sock.sendMessage(jid, {
        text: "❌ এই command শুধু Group-এ ব্যবহার করা যাবে।"
      });
    }

    const metadata = await sock.groupMetadata(jid);

    const sender = msg.key.participant || msg.key.remoteJid;
    const senderInfo = metadata.participants.find(p => p.id === sender);

    if (!senderInfo?.admin) {
      return sock.sendMessage(jid, {
        text: "❌ শুধু Group Admin এই command ব্যবহার করতে পারবে।"
      });
    }

    const botJid = sock.user?.id?.split(":")[0] + "@s.whatsapp.net";

    const targets = metadata.participants
      .filter(p => !p.admin && p.id !== botJid)
      .map(p => p.id);

    if (!targets.length) {
      return sock.sendMessage(jid, {
        text: "ℹ️ Remove করার মতো কোনো non-admin member নেই।"
      });
    }

    try {
      await sock.groupParticipantsUpdate(jid, targets, "remove");

      await sock.sendMessage(jid, {
        text: `✅ 𝗞𝗜𝗖𝗞 𝗔𝗟𝗟\n\n👥 Removed : ${targets.length}\n👑 Admins were kept safe.`
      });
    } catch (e) {
      await sock.sendMessage(jid, {
        text: "❌ Kick All failed. Bot-কে Group Admin করা আছে কিনা দেখো।"
      });
    }
  }
};
